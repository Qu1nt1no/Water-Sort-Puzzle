package execution;

import types.BettingFillingGame;

import types.Bottle;
import types.Emojis;
import types.Filling;
import types.Table;

public class Main {

	public static void main(String[] args) {
		
	}

}
