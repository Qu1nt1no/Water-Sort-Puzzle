package types;

public interface Filling {

	
	Filling[] fillings();

}
